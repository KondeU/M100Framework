﻿/************************************************************

GNU GENERAL PUBLIC LICENSE, Version 3, 29 June 2007
Copyright (c) 2017, KondeU, All rights reserved.
版权所有，代码遵循GPLv3协议。

Project:     M100Framework
File:        FlightIndoor.h
Description: Could only run on linux. Device is Manifold.
Date:        2017-06-30
Version:     2.1_CN
Authors:     Deyou Kong <370242479@qq.com>
History:     01, 17-06-30, Deyou Kong, Create file and implement it.
             02, 17-09-07, Deyou Kong, Use CLogger to log info.
			 03, 17-10-15, Deyou Kong, Remove external CLogger class and implement it locally.
			 **, 18-03-19, Deyou Kong, 添加中文版注释，请注意，中文版不提供升级维护，请以英文版为准。

************************************************************/

#pragma once

#include "Flight.h"

class CFlightIndoor : public CFlight // CFlightIndoor以public权限继承自CFlight，完善一些方便于室内飞行的控制
{
public:

	//CFlightIndoor(ConboardSDKScript * pst = nullptr) : CFlight(pst), cLog("FlightIndoor") {};
	CFlightIndoor(ConboardSDKScript * pst = nullptr) : CFlight(pst) {};

	void IdrFlyHeight(float fHeight); // 飞行到指定高度，精度不够准确，高精度控制请勿使用，单位米
	void IdrFlyUp(float fSpeed = 0.7); // 以给定速度上升，单位米每秒
	void IdrFlyDn(float fSpeed = 0.7); // 以给定速度下降，单位米每秒

	// 多控制参数飞行，
	// fSpeedX、fSpeedY为机身坐标系下X轴（前方）、Y轴（右方）的速度，单位米每秒
	// fHeight为飞行器高度，单位米
	// fYawRate为飞行器偏航角速度，以一定的角速度偏航飞行（绕自身旋转），单位角度每秒，限制最高速度为-100至+100度每秒
	void IdrFlying(float fSpeedX, float fSpeedY, float fHeight, float fYawRate = 0.0);

private:

	//CLogger cLog;
};

