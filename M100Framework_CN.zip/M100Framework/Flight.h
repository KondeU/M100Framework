﻿/************************************************************

GNU GENERAL PUBLIC LICENSE, Version 3, 29 June 2007
Copyright (c) 2017, KondeU, All rights reserved.
版权所有，代码遵循GPLv3协议。

Project:     M100Framework
File:        Flight.h
Description: Could only run on linux. Device is Manifold.
Date:        2017-06-30
Version:     2.1_CN
Authors:     Deyou Kong <370242479@qq.com>
History:     01, 17-06-30, Deyou Kong, Create file and implement it.
             02, 17-09-07, Deyou Kong, Use CLogger to log info.
			 03, 17-10-15, Deyou Kong, Remove external CLogger class and implement it locally.
			 **, 18-03-19, Deyou Kong, 添加中文版注释，请注意，中文版不提供升级维护，请以英文版为准。

************************************************************/

// 在Flight.cpp文件中CLogger类的public域的static变量中，有一个bFlightMove的bool型变量，指定了飞行器是否启用电机！
// 可将该标志位设定为false以禁用电机的转动，在此模式下可以进行飞行器调试、视觉图像处理的调试等！

#pragma once

#include "DJIHardDriverManifold.h"
#include "conboardsdktask.h"
#include "APIThread.h"

//#include "CLogger.h"

// 常量值与方法宏
#define C_PI ((double)(3.1415926535897932))
#define C_EARTH ((double)(6378137.0))
#define CL_RADTODEG(rad) ((rad)*(180)/(C_PI)) // 弧度转角度

// 遥控器上的Gear起落架拨杆状态宏
#define GEAR_ERR -1
#define GEAR_DN 0
#define GEAR_UP 1

// 结构体TGPS，保存GPS数据信息
struct TGPS
{
	double dLatitude;
	double dLongitude;
};

// 结构体TBaseLine，保存一条基线信息
struct TBaseLine
{
	TGPS tgpsOrg; // 基线的起始点GPS
	TGPS tgpsPnt; // 基线的经过点GPS
	double dX;
	double dY;
	double dK;
	// y=k*x，坐标系为坐标原点在tgpsOrg的北东坐标系
};

// 结构体TFlightState，保存飞行器信息
struct TFlightState
{
	BroadcastData bd; // 飞控发回的未解算的广播数据，内含飞行器的数据

	float fRoll, fPitch, fYaw; // 飞行器姿态信息
	float fSpeedX, fSpeedY; // 飞行器自身坐标系下速度信息，自身坐标系下，前方为X轴，右方为Y轴
	float fHeight; // 飞行器高度，气压计高度信息，受气流影响，准确度一般不太高，高精度的起降等请勿使用该值
	int iGear; // 起落架拨杆状态
};

// 类CFlight，M100飞行器常用控制类
class CFlight
{
public:

	// Cflight：构造函数
	// [in]ConboardSDKScript * pst：指向控制M100的实例的指针
	//CFlight(ConboardSDKScript * pst = nullptr) : cLog("Flight") { pScript = pst; }
	CFlight(ConboardSDKScript * pst = nullptr) { pScript = pst; }

	// SetScript：设置控制M100的实例指针
	// [in]ConboardSDKScript * pst：指向控制M100的实例的指针
	// [return]void：无
	// 内联函数
	inline void SetScript(ConboardSDKScript * pst) { pScript = pst; }

	// GetCrntGPS：获取当前GPS值
	// [return]TGPS：TGPS结构体，保存M100当前的GPS值
	TGPS GetCrntGPS();

	// CalcOffset：映射GPS到北东坐标系下解算距离
	// [out]double & x：基点到目标点在北东坐标系下的X轴（北方向）距离，单位为米
	// [out]double & y：基点到目标点在北东坐标系下的Y轴（东方向）距离，单位为米
	// [in]const TGPS & tgpsBase：待解算的基点GPS值，该点会被作为映射后北东坐标系的原点
	// [in]const TGPS & tgpsDest：待解算的目标GPS值，该点会被作为映射后北东坐标系的目标点
	// [return]void：无
	void CalcOffset(double & x, double & y, const TGPS & tgpsBase, const TGPS & tgpsDest);
	// CalcOffset：映射GPS到北东坐标系下解算距离，基点GPS会获取当前M100所在位置的GPS值
	// [out]double & x：基点到目标点在北东坐标系下的X轴（北方向）距离，单位为米
	// [out]double & y：基点到目标点在北东坐标系下的Y轴（东方向）距离，单位为米
	// [in]const TGPS & tgpsDest：待解算的目标GPS值，该点会被作为映射后北东坐标系的目标点
	// [return]void：无
	void CalcOffset(double & x, double & y, const TGPS & tgpsDest);

	// CalcGPS：映射北东坐标系下的距离到GPS点，CalcOffset的反求解，由北东坐标系下的距离计算出目标的GPS值
	// [in]const TGPS & tgpsBase：基点GPS值，该点指定了北东坐标系下的原点位置
	// [in]const double & x：基点到目标点在北东坐标系下的X轴（北方向）距离，单位为米
	// [in]const double & y：基点到目标点在北东坐标系下的Y轴（东方向）距离，单位为米
	// [return]TGPS：TGPS结构体，存储计算出的目标GPS值
	TGPS CalcGPS(const TGPS & tgpsBase, const double & x, const double & y);

	// CalcYaw：由北东坐标系下的距离值计算偏航角度，计算所得的偏航角度的参考坐标系为北东坐标系
	//          正北为+0或-0度，正南为+180或-180度，从正北到正南，顺时针方向为正，逆时针方向为负
	// [in]const double & x：北东坐标系下的X轴（北方向）距离，单位为米
	// [in]const double & y：北东坐标系下的Y轴（东方向）距离，单位为米
	// [return]float：计算得出的偏航角度，单位为角度
	float CalcYaw(const double & x, const double & y);
	// CalcYaw：由GPS计算偏航角度，计算所得的偏航角度的参考坐标系为北东坐标系，原点为输入参数中基点的GPS所在位置
	//          正北为+0或-0度，正南为+180或-180度，从正北到正南，顺时针方向为正，逆时针方向为负
	// [in]const TGPS & tgpsBase：基点的GPS
	// [in]const TGPS & tgpsDest：目标的GPS，计算的偏航角度即为目标GPS位置相对于基点GPS位置在北东坐标系下的角度
	// [return]float：计算得出的偏航角度，单位为角度
	float CalcYaw(const TGPS & tgpsBase, const TGPS & tgpsDest);
	// CalcYaw：由GPS计算偏航角度，计算所得的偏航角度的参考坐标系为北东坐标系，原点为M100当前的GPS位置
	//          正北为+0或-0度，正南为+180或-180度，从正北到正南，顺时针方向为正，逆时针方向为负
	// [in]const TGPS & tgpsDest：目标的GPS，计算的偏航角度即为目标GPS位置相对于基点GPS位置在北东坐标系下的角度
	// [return]float：计算得出的偏航角度，单位为角度
	float CalcYaw(const TGPS & tgpsDest);

	// IsNearDest：判断M100当前的位置是否接近于目标的GPS位置
	//             定义“接近”为当前位置在期望位置附近阈值所限定的一个圆心区域
	// [in]const TGPS & tgpsDest：目标的GPS，评判接近的参照
	// [in]float fNearThreshold：接近程度的阈值，若M100当前位置的GPS与目标的GPS解算出的距离小于该阈值，则判断为接近
	// [return]bool：true为接近，false为不接近
	bool IsNearDest(const TGPS & tgpsDest, float fNearThreshold = 0.5);

	// CalcBaseLine：根据GPS值计算在北东坐标系下的一条基线
	// [out]TBaseLine & tbl：计算出的基线信息
	// [in]const TGPS & tgpsOrg：基线过的一个点的GPS，该点将成为北东坐标系下的原点
	// [in]const TGPS & tgpsPnt：基线过的另一个点的GPS，该点仅用于计算出基线
	// [in]float fPrecision：精度，当基线斜率趋近于不存在时才使用，保持默认参数即可
	// [return]void：无
	void CalcBaseLine(TBaseLine & tbl, const TGPS & tgpsOrg, const TGPS & tgpsPnt, float fPrecision = 0.000001);

	// CalcDistance：计算飞行器当前位置距离基线的最短直线距离
	// [in]TBaseLine & tbl：需要计算的基线
	// [return]double：距离值，单位为米
	double CalcDistance(TBaseLine & tbl);

	// IsAltitudeInRange：判断飞行器的高度是否在给定的高度范围内，飞行器的高度信息准确度相对较低，高精度控制请勿使用
	// [in]const float fMin：给定的高度范围的最小值
	// [in]const float fMax：给定的高度范围的最大值
	// [out]float * pfDiff：可选项，若传递一个有效的float指针，将存储当前高度距离给定的高度范围的差值，
	//                      小于范围最低限为负值，大于范围最高限为正值
	// [return]int：返回0则在范围内，返回-1低于高度范围，返回+1高于高度范围
	int IsAltitudeInRange(const float fMin, const float fMax, float * pfDiff = nullptr);

	// GetBattery：获取电池电量信息
	// [return]int：电量的百分比，满电状态为100
	int GetBattery();

	// SetCameraAngle：设置相机云台的角度
	// [in]double dYaw：云台相对于机身坐标系的偏航角（绕Z轴），单位为角度
	// [in]double dRoll：云台相对于机身坐标系的横滚角（绕X轴），单位为角度
	// [in]double dPitch：云台相对于机身坐标系的俯仰角（绕Y轴），单位为角度
	// [return]void：无
	void SetCameraAngle(double dYaw, double dRoll, double dPitch);

	// GetGear：获得起落架拨杆状态
	// [return]int：拨杆状态宏
	int GetGear();

	// GetFlightState：获得飞行器当前所有的飞行信息，如姿态信息等
	// [out]TFlightState & tfs：保存飞行器信息的结构体
	// [return]void：无
	void GetFlightState(TFlightState & tfs);

	void CtrlObtain();  // 申请获取飞行器的控制权
	void CtrlRelease(); // 申请释放飞行器的控制权

	void Takeoff(); // 起飞
	void Land();    // 降落

	// 以下函数为飞行器飞行控制函数，用于控制飞行器的飞行，控制飞行器前必须先获取飞行器的控制权！！
	// FlyToward函数控制飞行器朝目标GPS点飞行，飞行器机头方向始终朝向目标点的方向
	// FlyYawing函数控制飞行器的偏航，控制飞行器的机头方向朝向北东坐标系下指定的偏航角度
	// FlyForward、FlyBack、FlyLeft、FlyRight函数分别控制飞行器在自身坐标系下朝前、后、左、右飞行
	// FlyUp、FlyDown函数控制飞行器以一定的速度上升或下降
	// 以下函数中的参数基本为输入型[in]类型参数，以下函数中参数的意义：
	// TGPS tgpsDest    ：目标的GPS
	// float fFlySpeed  ：飞行速度，单位为米每秒
	// float fFlyHeight ：飞行高度，单位为米
	// float * pfYaw    ：该参数为输出型[out]参数，可不传递，若传递一个float型指针，将返回当前飞行器机头的实际偏航角
	// float fYaw       ：飞行器偏航角，飞行器机头在北东坐标系下的偏航角，单位为角度
	// fUpSpeed、fDownSpeed：上升、下降速度，单位为米每秒

	void FlyToward(TGPS tgpsDest, float fFlySpeed = 0.7, float fFlyHeight = 3.0, float * pfYaw = nullptr);

	void FlyYawing(float fYaw, float fFlyHeight = 3.0);

	void FlyForward(float fYaw, float fFlySpeed = 0.7, float fFlyHeight = 3.0);
	void FlyBack(float fYaw, float fFlySpeed = 0.7, float fFlyHeight = 3.0);
	void FlyLeft(float fYaw, float fFlySpeed = 0.7, float fFlyHeight = 3.0);
	void FlyRight(float fYaw, float fFlySpeed = 0.7, float fFlyHeight = 3.0);

	void FlyUp(float fYaw, float fUpSpeed = 0.7);
	void FlyDown(float fYaw, float fDownSpeed = 0.7);

protected:

	ConboardSDKScript * pScript; // 指向控制M100的实例的指针

private:

	//CLogger cLog;
};

/*
FlightData control value:
Control mode byte
    bit7:6
        0b00：HORI_ATTI_TILT_ANG
        0b01：HORI_VEL
        0b10：HORI_POS
    bit5:4
        0b00：VERT_VEL
        0b01：VERT_POS
        0b10：VERT_THRUST
    bit3
        0b0: YAW_ANG
        0b1: YAW_RATE
    bit2:1
        0b00：horizontal frame is ground frame
        0b01：horizontal frame is body frame
    bit0
        0b0：non-stable mode
        0b1：stable mode
Linker:(Control mode byte):http://developer.dji.com/onboard-sdk/documentation/appendix/index.html
*/

