var indexSectionsWithContent =
{
  0: "_abcdefghilmnpqrstuvwy",
  1: "abcefghmpqrstvwy",
  2: "d",
  3: "d",
  4: "abcdfginprstu",
  5: "abcdhlmrstvw",
  6: "abceghmprsuvw",
  7: "acmsy",
  8: "ms",
  9: "_amnu",
  10: "dt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Pages"
};

